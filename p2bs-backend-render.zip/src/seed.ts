import bcrypt from 'bcrypt';
import { AppDataSource } from './data-source';
import { User } from './entities/User';

export async function seed(){
  const userRepo = AppDataSource.getRepository(User);
  const exists = await userRepo.findOneBy({ email: 'admin@example.com' });
  if(!exists){
    const hash = await bcrypt.hash('Pass@123', 10);
    const admin = userRepo.create({ name: 'Admin', email: 'admin@example.com', passwordHash: hash, role: 'admin' });
    await userRepo.save(admin);
    console.log('Seed: admin user created -> admin@example.com / Pass@123');
  }
}
