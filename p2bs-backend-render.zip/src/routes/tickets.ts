import { Router } from 'express';
import { AppDataSource } from '../data-source';
import { Ticket } from '../entities/Ticket';
import { authMiddleware, AuthedRequest } from '../middleware/auth';

const router = Router();

router.use(authMiddleware);

router.get('/', async (req: AuthedRequest, res) => {
  try{
    const ticketRepo = AppDataSource.getRepository(Ticket);
    const tickets = await ticketRepo.find({ order: { createdAt: 'DESC' } });
    res.json(tickets);
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/', async (req: AuthedRequest, res) => {
  try{
    const { title, description } = req.body;
    if(!title) return res.status(400).json({ message: 'Title required' });
    const ticketRepo = AppDataSource.getRepository(Ticket);
    const ticket = ticketRepo.create({ title, description, status: 'open', requesterId: req.user!.id });
    await ticketRepo.save(ticket);
    res.status(201).json(ticket);
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/:id', async (req: AuthedRequest, res) => {
  try{
    const ticketRepo = AppDataSource.getRepository(Ticket);
    const ticket = await ticketRepo.findOneBy({ id: req.params.id });
    if(!ticket) return res.status(404).json({ message: 'Not found' });
    res.json(ticket);
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/:id', async (req: AuthedRequest, res) => {
  try{
    const ticketRepo = AppDataSource.getRepository(Ticket);
    const ticket = await ticketRepo.findOneBy({ id: req.params.id });
    if(!ticket) return res.status(404).json({ message: 'Not found' });
    const { status, assigneeId, description } = req.body;
    if(status) ticket.status = status;
    if(typeof description !== 'undefined') ticket.description = description;
    if(assigneeId) ticket.assigneeId = assigneeId;
    await ticketRepo.save(ticket);
    res.json(ticket);
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
