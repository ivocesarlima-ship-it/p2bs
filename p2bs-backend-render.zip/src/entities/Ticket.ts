import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { User } from './User';

@Entity()
export class Ticket {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  title!: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({ default: 'open' })
  status!: string;

  @ManyToOne(() => User, user => user.tickets, { nullable: true })
  @JoinColumn({ name: 'requesterId' })
  requester?: User | null;

  @Column({ nullable: true })
  requesterId?: string | null;

  @Column({ nullable: true })
  assigneeId?: string | null;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt!: Date;
}
