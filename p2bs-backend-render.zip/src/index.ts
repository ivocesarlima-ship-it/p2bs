import 'reflect-metadata';
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import authRoutes from './routes/auth';
import ticketRoutes from './routes/tickets';
import { AppDataSource } from './data-source';
import { seed } from './seed';

const PORT = process.env.PORT ? parseInt(process.env.PORT) : 4000;

async function main(){
  await AppDataSource.initialize();
  await seed();

  const app = express();
  app.use(cors());
  app.use(bodyParser.json());

  app.get('/', (req, res) => res.json({ ok: true, version: 'p2bs-backend' }));
  app.use('/api/auth', authRoutes);
  app.use('/api/tickets', ticketRoutes);

  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
}

main().catch(err => { console.error('Failed to start', err); process.exit(1); });
