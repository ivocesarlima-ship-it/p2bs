import { Request, Response, NextFunction } from 'express';
import { verifyJwt } from '../utils/jwt';
import { AppDataSource } from '../data-source';
import { User } from '../entities/User';

export interface AuthedRequest extends Request {
  user?: User;
}

export async function authMiddleware(req: AuthedRequest, res: Response, next: NextFunction){
  const auth = req.headers.authorization;
  if(!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ message: 'Unauthorized' });
  const token = auth.split(' ')[1];
  try{
    const payload: any = verifyJwt(token);
    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOneBy({ id: payload.userId });
    if(!user) return res.status(401).json({ message: 'Unauthorized - user not found' });
    req.user = user;
    next();
  }catch(err){
    return res.status(401).json({ message: 'Invalid token' });
  }
}
