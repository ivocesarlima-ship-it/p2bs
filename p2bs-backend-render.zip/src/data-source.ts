import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { User } from './entities/User';
import { Ticket } from './entities/Ticket';

const databaseUrl = process.env.DATABASE_URL;
if(!databaseUrl){
  console.error('DATABASE_URL is not set. Abort.');
  // For safety, still allow startup for local testing with sqlite? We'll throw to force proper config.
  // throw new Error('DATABASE_URL must be set in environment');
}

export const AppDataSource = new DataSource({
  type: 'postgres',
  url: databaseUrl,
  synchronize: true,
  logging: false,
  entities: [User, Ticket],
});
