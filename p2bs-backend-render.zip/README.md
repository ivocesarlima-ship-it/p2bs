# p2bs-backend (Render-ready)

TypeScript + Express + TypeORM backend configured to use a Render PostgreSQL Database via `DATABASE_URL`.
Seed user: admin@example.com / Pass@123 (created on first start).

## Quickstart (local)
1. Copy `.env.example` to `.env` and set `DATABASE_URL` (for local Postgres) and `JWT_SECRET`.
2. `npm install`
3. `npm run dev`

## Deploy to Render
1. Create a new repo and push this project, or upload the zip.
2. On Render, create a new Web Service from the repo and enable autopublish.
3. Add a PostgreSQL Database (Render will create one) — the provided `render.yaml` will link it as `p2bs-db`.
4. The app will be available at: `https://p2bs-backend.onrender.com` (if name allowed).
